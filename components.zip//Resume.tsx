import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Download, MapPin, Mail, Phone, Linkedin, Github } from 'lucide-react';

const workExperiences = [
  {
    title: "Summer Instructor",
    company: "iDtech at Columbia University",
    period: "June 2025 – Aug 2025",
    location: "New York, NY",
    description: "Guided over 40+ students through the full development cycle of a game, from initial concept and design to implementation, VR feature integration, gameplay, and final project showcase. Taught fundamental programming and game development principles using C# in Unity and Lua in Roblox, instructing students on topics such as object-oriented programming, data structures, and game physics. Fostered collaborative learning and technical communication in classroom settings.",
    technologies: ["Roblox Studio", "Lua Script", "Unity", "C#"]
  }
];

const projectExperiences = [
  {
    title: "FPGA Matrix Multiply-Accumulate Accelerator",
    course: "Logic Design and Verification",
    period: "September 2025",
    description: "Implemented FPGA-based matrix MAC accelerator in SystemVerilog using Xilinx Vivado; optimized Block RAM and DSP usage and display results on seven-segment display. Applied pipelining and optimized dataflow to complete computation in 502 clock cycles under a 100 MHz clock, well within the 10 ns critical path requirement.",
    technologies: ["SystemVerilog", "Xilinx Vivado", "FPGA"]
  },
  {
    title: "Multiplication Coprocessor for RISC240",
    course: "FPGA Programming",
    period: "April 2025",
    description: "Developed a benchmark to evaluate 8-bit multiplication efficiency in RISC240 architecture using assembly code. Designed and integrated a multiplication coprocessor to enhance processing speed and reduce overhead. Validated improvements through Vivado synthesis and execution on the Xilinx XC7S50-CSG324A Spartan 7 FPGA board.",
    technologies: ["Vivado", "FPGA Programming", "Assembly"]
  },
  {
    title: "Serial Communication Error Correction",
    course: "Structure and Design of Digital Systems",
    period: "March 2025",
    description: "Designed and implemented a digital transmitter/receiver pair to process Bluetooth wireless signals that involved correcting the data received and transmitting them to a computer. Developed a hardware-accelerated error-correcting system using Hamming codes to detect and correct single-bit errors and detect double-bit errors in incoming messages. Built logic that uses edge-detection resynchronization to ensure accurate data sampling for clock mismatches between transmitter and receiver, ensuring reliable data transfer in serial communication.",
    technologies: ["Digital Systems", "Hamming Codes", "Bluetooth"]
  }
];

const leadershipExperiences = [
  {
    title: "Social Chair",
    organization: "Women in Electrical and Computer Engineering",
    period: "May 2025 - Present",
    location: "Pittsburgh, PA",
    description: "Planned and executed weekly social events, including technical workshops, with 30+ attendees per event. Managed event logistics and collaborated with team members to promote engagement and inclusivity within the Electrical and Computer Engineering community.",
    technologies: []
  },
  {
    title: "Events/Finance Chair",
    organization: "Project Smile",
    period: "February 2025 – Present",
    location: "Pittsburgh, PA",
    description: "Spearheaded large-scale community events, such as \"Build-Your-Own-Bouquet\" workshop and a \"Boba Care Package\" giveaway, that engaged over 350+ students and fostered a positive campus environment. Developed and managed the annual event roadmap, coordinating event sizes and budgets to ensure successful execution throughout the year. Effectively utilized inventory resources to optimize event supplies and reduce costs.",
    technologies: []
  }
];

const education = [
  {
    degree: "Bachelor of Science in Electrical and Computer Engineering",
    school: "Carnegie Mellon University",
    period: "Expected May 2027",
    location: "Pittsburgh, PA",
    description: "Relevant Courses: Structure and Design of Digital Systems, Electronic Devices and Analog Circuits, Data Structures and Algorithms, Computer Systems, Introduction to Embedded Systems, Logic Design and Verification",
    organizations: "Organizations: Rewriting The Code, Girls Who Code, Women in Electrical & Computer Engineering"
  }
];

const skills = [
  { category: "Software", items: ["Vivado", "VCS", "Vim", "Git", "Visual Studio IDE", "Linux", "Windows", "Autodesk Fusion", "SOLIDWORKS"] },
  { category: "Languages", items: ["Python", "C/C++", "Java", "MATLAB", "SystemVerilog", "Verilog", "Assembly"] },
  { category: "Technical", items: ["PCB Design and Layout", "Soldering", "Laser Cutting", "3D Printing", "Oscilloscope", "Digital Multimeter"] }
];

export function Resume() {
  return (
    <section id="resume" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl mb-4 text-white">Resume</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
            Electrical & Computer Engineering student with hands-on experience in embedded systems, 
            digital design, and AI applications in hardware optimization.
          </p>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors"
          >
            <Download className="w-4 h-4" />
            Download PDF
          </motion.button>
        </motion.div>

        {/* Contact Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-muted-foreground" />
                  <span>pzhu2@andrew.cmu.edu</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-muted-foreground" />
                  <span>+1 (917) 691-3651</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-muted-foreground" />
                  <span>New York, NY</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Linkedin className="w-4 h-4 text-muted-foreground" />
                    <span>LinkedIn</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Github className="w-4 h-4 text-muted-foreground" />
                    <span>GitHub</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Education */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl mb-8 text-white">Education</h3>
          <div className="space-y-6">
            {education.map((edu, index) => (
              <motion.div
                key={edu.degree}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{edu.degree}</CardTitle>
                        <CardDescription className="flex items-center gap-4 mt-1">
                          <span>{edu.school}</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {edu.location}
                          </span>
                        </CardDescription>
                      </div>
                      <Badge variant="outline">{edu.period}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-2">{edu.description}</p>
                    <p className="text-muted-foreground">{edu.organizations}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Skills */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl mb-8 text-white">Skills</h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skillGroup, index) => (
              <motion.div
                key={skillGroup.category}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">{skillGroup.category}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {skillGroup.items.map((skill) => (
                        <Badge key={skill} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Project Experience */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl mb-8 text-white">Project Experience</h3>
          <div className="space-y-6">
            {projectExperiences.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{project.title}</CardTitle>
                        <CardDescription className="mt-1">
                          <span>{project.course}</span>
                        </CardDescription>
                      </div>
                      <Badge variant="outline">{project.period}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{project.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech) => (
                        <Badge key={tech} variant="secondary" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Work Experience */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <h3 className="text-2xl mb-8 text-white">Work Experience</h3>
          <div className="space-y-6">
            {workExperiences.map((exp, index) => (
              <motion.div
                key={exp.title + exp.company}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{exp.title}</CardTitle>
                        <CardDescription className="flex items-center gap-4 mt-1">
                          <span>{exp.company}</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {exp.location}
                          </span>
                        </CardDescription>
                      </div>
                      <Badge variant="outline">{exp.period}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-4">{exp.description}</p>
                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.map((tech) => (
                        <Badge key={tech} variant="secondary" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Leadership Experience */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          viewport={{ once: true }}
        >
          <h3 className="text-2xl mb-8 text-white">Leadership Experience</h3>
          <div className="space-y-6">
            {leadershipExperiences.map((leadership, index) => (
              <motion.div
                key={leadership.title + leadership.organization}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{leadership.title}</CardTitle>
                        <CardDescription className="flex items-center gap-4 mt-1">
                          <span>{leadership.organization}</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {leadership.location}
                          </span>
                        </CardDescription>
                      </div>
                      <Badge variant="outline">{leadership.period}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{leadership.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}