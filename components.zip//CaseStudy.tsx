/*
 * CASE STUDY TEMPLATE
 * 
 * To add your own case studies:
 * 1. Replace the template data in the caseStudies array below
 * 2. For images, use the unsplash_tool to get relevant images
 * 3. Update the links to point to your actual repositories/demos
 * 4. Add as many case studies as you want by copying the template structure
 * 
 * Each case study should showcase a deep dive into your most impactful projects
 */

import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { ArrowRight, Clock, Users, Trophy, ExternalLink } from 'lucide-react';

// TEMPLATE: Fill in your actual case studies here
const caseStudies = [
  {
    title: "Project Title 1", // Replace with your actual project title
    subtitle: "One-line project description", // Brief description of what the project is
    description: "Detailed description of your project, what problem it solved, and the approach you took. Make this 2-3 sentences that give a good overview.", // Full project description
    image: "https://images.unsplash.com/photo-1598845685288-98d5e7128987?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWNyb2NoaXAlMjBwcm9jZXNzb3IlMjB0ZWNobm9sb2d5fGVufDF8fHx8MTc1OTE1OTE0MHww&ixlib=rb-4.1.0&q=80&w=1080", // Replace with relevant image search term for unsplash_tool
    duration: "X months", // How long the project took
    team: "Individual/Team of X", // Team size and structure
    outcome: "Key achievement or metric", // Main result or accomplishment
    technologies: ["Tech1", "Tech2", "Tech3"], // List of technologies used
    highlights: [
      "Key accomplishment 1",
      "Key accomplishment 2", 
      "Key accomplishment 3",
      "Key accomplishment 4"
    ], // 3-4 bullet points of main achievements
    link: "https://github.com/yourusername/project-repo" // Link to GitHub repo, demo, or case study
  },
  {
    title: "Project Title 2",
    subtitle: "Another project description",
    description: "Another detailed description of a different project. Focus on the technical challenges and solutions you implemented.",
    image: "https://images.unsplash.com/photo-1580835920383-4c480fece410?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wdXRlciUyMGVuZ2luZWVyaW5nJTIwdGVjaG5vbG9neXxlbnwxfHx8fDE3NTkxNTkxMjd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    duration: "X months",
    team: "Individual/Team of X",
    outcome: "Key achievement or metric",
    technologies: ["Tech1", "Tech2", "Tech3"],
    highlights: [
      "Key accomplishment 1",
      "Key accomplishment 2",
      "Key accomplishment 3",
      "Key accomplishment 4"
    ],
    link: "https://github.com/yourusername/project-repo-2"
  }
  // Add more case studies by copying the template above
];

export function CaseStudy() {
  return (
    <section id="case-studies" className="py-24 px-6">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl mb-4 text-white">Case Studies</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Deep dives into my most impactful engineering projects, showcasing problem-solving approaches and technical implementations.
          </p>
        </motion.div>

        <div className="space-y-16">
          {caseStudies.map((study, index) => (
            <motion.div
              key={study.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="overflow-hidden">
                <div className="grid lg:grid-cols-2 gap-0">
                  {/* Image */}
                  <div className="relative h-64 lg:h-auto">
                    <ImageWithFallback
                      src={study.image}
                      alt={study.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                  </div>
                  
                  {/* Content */}
                  <div className="p-8">
                    <CardHeader className="p-0 mb-6">
                      <CardTitle className="text-2xl mb-2 text-white">{study.title}</CardTitle>
                      <CardDescription className="text-lg text-muted-foreground">
                        {study.subtitle}
                      </CardDescription>
                    </CardHeader>
                    
                    <CardContent className="p-0 space-y-6">
                      <p className="text-muted-foreground leading-relaxed">
                        {study.description}
                      </p>
                      
                      {/* Project Stats */}
                      <div className="grid grid-cols-3 gap-4">
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-primary" />
                          <div>
                            <p className="text-xs text-muted-foreground">Duration</p>
                            <p className="text-sm">{study.duration}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4 text-primary" />
                          <div>
                            <p className="text-xs text-muted-foreground">Team</p>
                            <p className="text-sm">{study.team}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Trophy className="w-4 h-4 text-primary" />
                          <div>
                            <p className="text-xs text-muted-foreground">Outcome</p>
                            <p className="text-sm">{study.outcome}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Technologies */}
                      <div>
                        <h4 className="text-sm mb-2 text-white">Technologies Used</h4>
                        <div className="flex flex-wrap gap-2">
                          {study.technologies.map((tech) => (
                            <Badge key={tech} variant="secondary" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      
                      {/* Key Highlights */}
                      <div>
                        <h4 className="text-sm mb-3 text-white">Key Highlights</h4>
                        <ul className="space-y-2">
                          {study.highlights.map((highlight, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                              <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                              {highlight}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      {/* CTA */}
                      <motion.a
                        href={study.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 text-white hover:text-gray-300 transition-colors"
                        whileHover={{ x: 5 }}
                      >
                        View Full Case Study
                        <ExternalLink className="w-4 h-4" />
                      </motion.a>
                    </CardContent>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}